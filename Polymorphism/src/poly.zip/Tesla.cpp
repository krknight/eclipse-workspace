/*
 * Tesla.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: kknight
 */

#include "Tesla.h"
#include <iostream>

using namespace std;

Tesla::Tesla() {

}

Tesla::~Tesla() {

}

void Tesla::propulsion() {
	cout << "Electric AC Motors" << endl;
}

void Tesla::show() {
	cout << "Tesla" << endl;
}


