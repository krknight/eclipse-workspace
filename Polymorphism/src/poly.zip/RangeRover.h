/*
 * RangeRover.h
 *
 *  Created on: Apr 23, 2019
 *      Author: kknight
 */

#ifndef RANGEROVER_H_
#define RANGEROVER_H_

#include "vehicle.h"

class RangeRover : public vehicle {
public:
	void propulsion();
	void show();
};

#endif /* RANGEROVER_H_ */
