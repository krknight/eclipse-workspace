/*
 * RangeRover.cpp
 *
 *  Created on: Apr 23, 2019
 *      Author: kknight
 */

#include "RangeRover.h"
#include <iostream>

using namespace std;

//RangeRover::RangeRover() {
//
//}

void RangeRover::propulsion() {
	cout << "Internal Combustion" << endl;
}

void RangeRover::show() {
	cout << "RangeRover" << endl;
}


